using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AccretionDiskController : MonoBehaviour
{
    public SpriteRenderer accreditionRenderer;
    public CircleCollider2D horizonCollider;

    private void Update()
    {
        Vector3 centerPosition = accreditionRenderer.bounds.center;
        horizonCollider.transform.position = centerPosition;
    }
}
