using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Deplacement : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;

    private bool isInHorizon = false;
    private CircleCollider2D horizonCollider;

    public float vitesse = 5f;
    // Temps avant la destruction du vaisseau une fois à l'intérieur de l'accrétion
    public float destructionDelay = 1f;
    private float destructionTimer = 0f;

    //private int score = 1;
    private float score = 1f;
    public ScoreDisplay scoreDisplay;

    // Vitesse de rotation initiale
    public float rotationSpeed = 6000f;
    // Vitesse de rotation maximale
    public float maxRotationSpeed = 8000f;
    // Augmentation de la vitesse de rotation par seconde
    public float rotationSpeedIncrease = 1000f;

    // Start is called before the first frame update
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        horizonCollider = GameObject.FindWithTag("HorizonCollider").GetComponent<CircleCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float deplacementHorizontal = Input.GetAxis("Horizontal");
        float deplacementVertical = Input.GetAxis("Vertical");
 
        if (isInHorizon)
        {



            // Limiter le déplacement à l'intérieur de l'horizon des événements
            float newX = Mathf.Clamp(transform.position.x + deplacementHorizontal * vitesse * Time.deltaTime, horizonCollider.bounds.min.x, horizonCollider.bounds.max.x);
            float newY = Mathf.Clamp(transform.position.y + deplacementVertical * vitesse * Time.deltaTime, horizonCollider.bounds.min.y, horizonCollider.bounds.max.y);
            transform.position = new Vector3(newX, newY, transform.position.z);

                            // Augmenter la vitesse de rotation progressivement jusqu'à la vitesse maximale
            rotationSpeed += rotationSpeedIncrease * Time.deltaTime;
            rotationSpeed = Mathf.Min(rotationSpeed, maxRotationSpeed);
            // Appliquer la rotation autour de l'axe Z
            transform.Rotate(Vector3.forward, rotationSpeed * Time.deltaTime);


            // Désactiver les contrôles et déclencher la destruction après le délai
            destructionTimer += Time.deltaTime;
            if (destructionTimer >= destructionDelay)
            {
                // Désactiver les contrôles (par exemple, en désactivant le script de mouvement)
                enabled = false;
                // Détruire le vaisseau après un délai supplémentaire pour l'effet visuel
                Destroy(gameObject, 2f);
            }
        }
        else {
            // déplacement du vaisseau : il peut se déplacer sur X et Y mais aussi entre X et Y
            // Réinitialiser la vitesse de rotation lorsque le vaisseau sort de l'horizon
            rotationSpeed = 50f;
            Vector2 deplacement = new Vector2(deplacementHorizontal, deplacementVertical) * vitesse * Time.deltaTime;
            transform.Translate(deplacement);

            if (deplacement != Vector2.zero)
            {
                float angle = Mathf.Atan2(deplacement.y, deplacement.x) * Mathf.Rad2Deg;
                transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            }
        }
        // Gestion de la limite de la map : si le vaisseau sort par un coté de l'écran il réapparait au côté opposé.
        Vector3 viewportPosition = Camera.main.WorldToViewportPoint(transform.position) ;
        if (viewportPosition.x > 1f) {
            viewportPosition.x = 0f;
        } else if (viewportPosition.x < 0f) {
            viewportPosition.x = 1f ;
        }
        if (viewportPosition.y > 1f) {
            viewportPosition.y = 0f;
        } else if (viewportPosition.y < 0f) {
            viewportPosition.y = 1f ;
        }
        transform.position = Camera.main.ViewportToWorldPoint(viewportPosition);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Debug.Log("JE SUIS DANS OnTriggerEnter2D");
        if (collision.CompareTag("HorizonCollider"))
        {
            isInHorizon = true;
            //Debug.Log("Le vaisseau est dans l'horizon des événements !");
        }
        /*
        if (collision.CompareTag("Meteore"))
        {
            Debug.Log("Je touche un météore et je suis en mouvement !");
            score++;
            Destroy(collision.gameObject);
            Debug.Log("Score: " + score);
        }
        */
    }
 
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("HorizonCollider"))
        {
            isInHorizon = false;
            //Debug.Log("Le vaisseau est sorti de l'horizon des événements !");
        }
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        
        if (collision.collider.CompareTag("Meteore"))
        {
            float deplacementHorizontal = Input.GetAxis("Horizontal");
            float deplacementVertical = Input.GetAxis("Vertical");
            Vector2 deplacement = new Vector2(deplacementHorizontal, deplacementVertical);
            if (deplacement != Vector2.zero)  {
                // Debug.Log("JE TOUCHE UN METEORE");
                // Augmenter le score et détruire le météore capturé
                MeteoreController meteoreController = collision.gameObject.GetComponent<MeteoreController>();
                //score++;
                /* ancien code avec arrondi
                float divisionResult = (score / meteoreController.coeffDistance()) * 5;
                int roundedResult = Mathf.RoundToInt(divisionResult);
                */
                //float divisionResult = score / meteoreController.coeffDistance();
                // Score calculé sur l'inverse du carré de la distance
                float coeffDistance = meteoreController.coeffDistance();
                float divisionResult = score * (1 / (coeffDistance * coeffDistance));
                //float roundedResult = divisionResult;
                score = score + divisionResult;
                //scoreDisplay.AddScore(points);

                Destroy(collision.gameObject);

                // Mettre à jour le score affiché ou effectuer d'autres actions nécessaires
                //Debug.Log("Score: " + score);
                scoreDisplay.AddScore(score);
            }
        }
    }
}
