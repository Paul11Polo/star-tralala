using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreDisplay : MonoBehaviour
{
    public TextMeshPro scoreText;
    private float score = 0f;

    private void Start()
    {
        //scoreText = GetComponent<Text>();
        //UpdateScoreText();
    }

    public void AddScore(float points)
    {
        score += points;
        UpdateScoreText();
    }

    private void UpdateScoreText()
    {
        scoreText.text = score.ToString();
    }
}
