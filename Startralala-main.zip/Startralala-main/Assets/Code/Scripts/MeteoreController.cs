using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteoreController : MonoBehaviour
{
    private float rotationSpeed;
    private Vector3 trouNoirPosition;
    private TrouNoirController trouNoirController;
    private Transform accreditionLayer;

    public GameObject vaisseauSpatial;

    private bool isAttracted = false;
    private float attractionSpeed = 0.1f;
    private float destructionDistance = 0.5f;
    //private float destroyDelay = 3f;

    public void SetRotationSpeed(float speed)
    {
        rotationSpeed = speed;
    }
    private void Start()
    {
        trouNoirController = TrouNoirController.Instance;
        //trouNoirPosition = TrouNoirController.Instance.GetTrouNoirPosition();
        trouNoirPosition = trouNoirController.GetTrouNoirPosition();

        if (trouNoirController != null)
        {
            accreditionLayer = trouNoirController.accretionLayer;
            //trouNoirPosition = accreditionLayer.position;
        }
    }
    private void Update()
    {
        // Faire tourner le météore autour du trou noir à la vitesse de rotation donnée
        //transform.RotateAround(Vector3.zero, Vector3.forward, rotationSpeed * Time.deltaTime);
        transform.RotateAround(trouNoirPosition, Vector3.forward, rotationSpeed * Time.deltaTime);

         if (!isAttracted && trouNoirController != null)
        {
            
            // Récupérer la position du trou noir
            Vector3 trouNoirPosition = trouNoirController.transform.position;
            // Faire tourner le météore autour du trou noir à la vitesse de rotation donnée
            transform.RotateAround(trouNoirPosition, Vector3.forward, rotationSpeed * Time.deltaTime);

            // Calculer la direction et la distance entre le météore et le trou noir
            Vector3 direction = (trouNoirPosition - transform.position).normalized;
            float distance = Vector3.Distance(transform.position, trouNoirPosition);
            
            //Debug.Log("DISTANCE : " + distance);

            // Si le météore est suffisamment proche du trou noir, l'attirer progressivement
            if (distance > destructionDistance)
            {
                transform.position += direction * attractionSpeed * Time.deltaTime;
            } else {
                Destroy(gameObject);
            }
        }
    }

    public float coeffDistance () {
            // Récupérer la position du trou noir
            Vector3 trouNoirPosition = trouNoirController.transform.position;
            // Faire tourner le météore autour du trou noir à la vitesse de rotation donnée
            transform.RotateAround(trouNoirPosition, Vector3.forward, rotationSpeed * Time.deltaTime);

            // Calculer la direction et la distance entre le météore et le trou noir
            Vector3 direction = (trouNoirPosition - transform.position).normalized;
            float distance = Vector3.Distance(transform.position, trouNoirPosition);
            
            //Debug.Log("COEFF DISTANCE : " + distance);
            return distance;
    }

    private void OnDestroy()
    {
        //Debug.Log("Points obtenus : " + this.GetPoints());
    }
}

