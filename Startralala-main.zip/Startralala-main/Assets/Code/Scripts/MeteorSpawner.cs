using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorSpawner : MonoBehaviour
{
    public GameObject meteorePrefab;
    public Transform trouNoir;
    public float minDistance = 10f;
    public float maxDistance = 50f;
    public float minRotationSpeed = 20f;
    public float maxRotationSpeed = 60f;
    public int minMeteorCount = 20;
    public int maxMeteorCount = 30;
    public int respawnThreshold = 18;

    // Start is called before the first frame update
    void Start()
    {
        SpawnMeteores(Random.Range(20, 30));
    }

    private void SpawnMeteores(int count)
    {
        Debug.Log("Nombre de meteores a spanwer : " + count);
        //int numberOfMeteors = Random.Range(20, 30);
        for (int i=0; i < count; i++) {
            float distance = Random.Range(minDistance, maxDistance);
            float angle = Random.Range(0f, 360f);
            Vector3 spawnPosition = trouNoir.position + Quaternion.Euler(0f, 0f, angle) * Vector3.right * distance * 0.5f;

            GameObject meteore = Instantiate(meteorePrefab, spawnPosition, Quaternion.identity);
            MeteoreController meteoreController = meteore.GetComponent<MeteoreController>();

            if (meteoreController != null) {
                // Récupérer la référence au collider2D du météore
                Collider2D meteoreCollider = meteore.GetComponent<Collider2D>();

                float scale = Random.Range(0.06333175f, 0.1131548f);
                Vector3 randomScale = new Vector3(scale, scale, scale);
                meteore.transform.localScale = randomScale;
                float rotationSpeed = Random.Range(minRotationSpeed, maxRotationSpeed);
                meteoreController.SetRotationSpeed(rotationSpeed);
                // Par exemple, pour un Circle Collider 2D :
                CircleCollider2D circleCollider = meteoreCollider as CircleCollider2D;
                if (circleCollider != null)
                {
                    // Récupérer la taille du météore
                    float meteoreSize = meteore.GetComponent<SpriteRenderer>().bounds.size.x;

                    // Ajuster le rayon du collider en fonction de la taille du météore
                    circleCollider.radius = meteoreSize / 1f;
                }
                else
                {
                    Debug.LogError("CircleCollider2D component not found on the meteore prefab.");
                }
            }
            else {
                Debug.LogError("MeteoreController component not found on the meteore prefab.");
             }
        }
    }

    // Update is called once per frame
    void Update()
    {
        int currentMeteorCount = FindObjectsOfType<MeteoreController>().Length;
        if (currentMeteorCount <= respawnThreshold)
        {
            //int meteorsToSpawn = Random.Range(5, Mathf.Min(maxMeteorCount - currentMeteorCount, 15));
            int meteorsToSpawn = Random.Range(5, 15);
            SpawnMeteores(meteorsToSpawn);
        }
    }
}