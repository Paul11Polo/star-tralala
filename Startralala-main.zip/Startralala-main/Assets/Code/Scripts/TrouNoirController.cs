using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrouNoirController : MonoBehaviour
{
    public static TrouNoirController Instance { get; private set; }

    public Camera mainCamera;
    public Transform accretionLayer;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        //transform.position = mainCamera.transform.position;    
    }

    // Update is called once per frame
    void Update()
    {
        //transform.position = mainCamera.transform.position;
        accretionLayer.Rotate(Vector3.forward, 100f * Time.deltaTime);
    }

    public Vector3 GetTrouNoirPosition()
    {
        return transform.position;
    }
}
